class_name Player
extends CharacterBody2D

var state = State.NORMAL
enum State{NORMAL, DEAD, RESPAWING}

const SPEED = 130.0
const JUMP_VELOCITY = -220.0
@onready var animated_sprite: AnimatedSprite2D = $AnimatedSprite2D


func _physics_process(delta: float) -> void:
	# Add the gravity.
	if not is_on_floor():
		velocity += get_gravity() * delta

	# Handle jump.
	if Input.is_action_just_pressed("jump") and is_on_floor():
		velocity.y = JUMP_VELOCITY
	
	if state != State.NORMAL:
		move_and_slide()
		return
	
	var direction := Input.get_axis("move_left", "move_right")
	if direction > 0:
		animated_sprite.flip_h = false
	elif direction < 0:
		animated_sprite.flip_h = true
	if is_on_floor():
		if direction == 0:
			animated_sprite.play("Idle")
		else:
			animated_sprite.play("Run")
	else:
		animated_sprite.play("jump")
	
	if direction:
		velocity.x = direction * SPEED
	else:
		velocity.x = move_toward(velocity.x, 0, SPEED)

	move_and_slide()

func death():
	if state != State.NORMAL:
		return
	state = State.DEAD
	velocity = Vector2.ZERO
	animated_sprite.play("death")
	await get_tree().create_timer(0.5).timeout

func respawn():
	state = State.RESPAWING
	global_position = Vector2(396.0, 276.0)
	state = State.NORMAL
	
	var new_anim = ""
	if state == State.DEAD:
		new_anim = "death"
	
	
	
	
